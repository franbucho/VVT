import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Language } from "../localization";
import { TranslationKeys } from "../localization/en";

let aiInstance: GoogleGenAI | null = null;
let initError: string | null = null;

function getAiInstance(): GoogleGenAI {
  // If an initialization error occurred previously, throw it again.
  if (initError) {
    throw new Error(initError);
  }
  // If the instance already exists, return it.
  if (aiInstance) {
    return aiInstance;
  }

  // This is the first time the function is called, so initialize the AI client.
  try {
    // Safely access the API key to prevent a ReferenceError in browser environments.
    const apiKey = (typeof process !== 'undefined' && process.env && process.env.API_KEY)
      ? process.env.API_KEY
      : null;

    if (!apiKey) {
      console.error("API_KEY for Gemini is not set. Please set the environment variable.");
      // Set an error that will be thrown if the service is used.
      initError = 'error_generic_api_key_missing';
      throw new Error(initError);
    }
    
    aiInstance = new GoogleGenAI({ apiKey });
    return aiInstance;

  } catch (error) {
    console.error("Failed to initialize Gemini AI Service:", error);
    if (error instanceof Error && error.message.startsWith('error_')) {
        initError = error.message;
    } else {
        initError = 'error_generic_unexpected_api';
    }
    throw new Error(initError);
  }
}

const getLocalizedPrompt = (language: Language): string => {
  if (language === 'es') {
    return "Proporciona 5 consejos concisos y prácticos sobre salud ocular general para adultos. Cada consejo en una nueva línea, comenzando con una viñeta o guion.";
  }
  // Default to English
  return "Provide 5 concise, actionable general eye health tips for adults. Each tip on a new line, starting with a bullet or dash.";
};

export const getGeneralEyeHealthTips = async (language: Language): Promise<string> => {
  try {
    const ai = getAiInstance(); // This will initialize the AI on the first call.
    const localizedPrompt = getLocalizedPrompt(language);

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: localizedPrompt,
      config: {
        temperature: 0.7,
        topK: 40,
        topP: 0.95,
      }
    });
    
    const text = response.text;
    
    if (!text) {
      throw new Error('error_generic_no_tips_received');
    }
    return text;

  } catch (error) {
    console.error("Error fetching eye health tips from Gemini:", error);
    if (error instanceof Error) {
       // Re-throw known error keys or a generic one
       if (error.message.startsWith('error_generic_')) {
          throw error;
       }
       if (error.message.includes("API key not valid")) {
         throw new Error('error_generic_api_key_invalid' as keyof TranslationKeys);
      }
    }
    throw new Error('error_generic_unexpected_api' as keyof TranslationKeys);
  }
};
