
import { User } from '../types';

// Mock database
const users: User[] = [
  { id: '1', email: 'test@example.com' }
];

export const login = (email: string, password_unused: string): Promise<User | null> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const user = users.find(u => u.email === email); // Simplified: password check omitted
      if (user) {
        resolve(user);
      } else {
        reject(new Error("Invalid email or password."));
      }
    }, 1000);
  });
};

export const register = (email: string, password_unused: string): Promise<User | null> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (users.find(u => u.email === email)) {
        reject(new Error("User with this email already exists."));
        return;
      }
      const newUser: User = { id: String(users.length + 1), email };
      users.push(newUser); // In a real app, hash password etc.
      resolve(newUser);
    }, 1000);
  });
};
