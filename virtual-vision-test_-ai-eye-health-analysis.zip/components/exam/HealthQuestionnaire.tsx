
import React, { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { HealthData } from '../../types';
import { Button } from '../common/Button';

interface HealthQuestionnaireProps {
  onSubmit: (data: HealthData) => void;
}

const initialFormData: HealthData = {
  primaryReason: '',
  wearsLenses: '',
  lensesSatisfaction: '',
  lensesLastUpdate: '',
  hadSurgeryOrInjury: '',
  surgeryOrInjuryDetails: '',
  illnesses: {
    diabetes: false,
    highBloodPressure: false,
    highCholesterol: false,
    thyroid: false,
    arthritis: false,
    other: '',
  },
  familyHistory: {
    glaucoma: false,
    macularDegeneration: false,
    strabismus: false,
    highMyopia: false,
    other: '',
  },
  symptoms: {
    pain: false,
    itching: false,
    burning: false,
    tearing: false,
    gritty: false,
    lightSensitivity: false,
    doubleVision: false,
    none: false,
  },
};

export const HealthQuestionnaire: React.FC<HealthQuestionnaireProps> = ({ onSubmit }) => {
  const { t } = useLanguage();
  const [formData, setFormData] = useState<HealthData>(initialFormData);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleRadioChange = (name: keyof HealthData, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleCheckboxGroupChange = (group: 'illnesses' | 'familyHistory' | 'symptoms', name: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      [group]: {
        ...prev[group],
        [name]: checked,
      }
    }));
  };
  
   const handleOtherTextChange = (group: 'illnesses' | 'familyHistory', value: string) => {
    setFormData(prev => ({
        ...prev,
        [group]: {
            ...prev[group],
            other: value
        }
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };
  
  const renderCheckbox = (group: 'illnesses' | 'familyHistory' | 'symptoms', name: string, labelKey: any) => (
      <label key={name} className="flex items-center space-x-2 text-sm text-gray-700">
        <input
          type="checkbox"
          name={name}
          checked={(formData[group] as any)[name]}
          onChange={(e) => handleCheckboxGroupChange(group, name, e.target.checked)}
          className="rounded border-gray-300 accent-primary focus:ring-primary-light"
        />
        <span>{t(labelKey)}</span>
      </label>
  );

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <p className="text-gray-600 text-sm">{t('questionnaire_intro')}</p>
      
      {/* Question 1 */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">{t('q1_label')}</label>
        <textarea
          name="primaryReason"
          value={formData.primaryReason}
          onChange={handleInputChange}
          rows={3}
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm bg-white"
          placeholder={t('q1_placeholder')}
          required
        />
      </div>

      {/* Question 2 */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">{t('q2_label')}</label>
        <div className="flex items-center space-x-4">
          <label className="flex items-center space-x-2"><input type="radio" name="wearsLenses" value="yes" checked={formData.wearsLenses === 'yes'} onChange={() => handleRadioChange('wearsLenses', 'yes')} className="accent-primary focus:ring-primary-light" /> <span>{t('q2_yes')}</span></label>
          <label className="flex items-center space-x-2"><input type="radio" name="wearsLenses" value="no" checked={formData.wearsLenses === 'no'} onChange={() => handleRadioChange('wearsLenses', 'no')} className="accent-primary focus:ring-primary-light" /> <span>{t('q2_no')}</span></label>
        </div>
        {formData.wearsLenses === 'yes' && (
          <div className="mt-4 space-y-4 pl-2 border-l-2 border-primary-light">
            <div>
                <label htmlFor="lensesSatisfaction" className="block text-xs font-medium text-gray-600 mb-1">{t('q2_satisfactionLabel')}</label>
                <input id="lensesSatisfaction" type="text" name="lensesSatisfaction" value={formData.lensesSatisfaction} onChange={handleInputChange} className="mt-1 block w-full px-3 py-1.5 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm bg-white" placeholder={t('q2_satisfactionPlaceholder')} />
            </div>
            <div>
                <label htmlFor="lensesLastUpdate" className="block text-xs font-medium text-gray-600 mb-1">{t('q2_lastUpdateLabel')}</label>
                <input id="lensesLastUpdate" type="text" name="lensesLastUpdate" value={formData.lensesLastUpdate} onChange={handleInputChange} className="mt-1 block w-full px-3 py-1.5 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm bg-white" placeholder={t('q2_lastUpdatePlaceholder')} />
            </div>
          </div>
        )}
      </div>
      
      {/* Question 3 */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">{t('q3_label')}</label>
        <div className="flex items-center space-x-4">
          <label className="flex items-center space-x-2"><input type="radio" name="hadSurgeryOrInjury" value="yes" checked={formData.hadSurgeryOrInjury === 'yes'} onChange={() => handleRadioChange('hadSurgeryOrInjury', 'yes')} className="accent-primary focus:ring-primary-light" /> <span>{t('q2_yes')}</span></label>
          <label className="flex items-center space-x-2"><input type="radio" name="hadSurgeryOrInjury" value="no" checked={formData.hadSurgeryOrInjury === 'no'} onChange={() => handleRadioChange('hadSurgeryOrInjury', 'no')} className="accent-primary focus:ring-primary-light" /> <span>{t('q2_no')}</span></label>
        </div>
         {formData.hadSurgeryOrInjury === 'yes' && (
            <div className="mt-4 pl-2 border-l-2 border-primary-light">
                 <label htmlFor="surgeryOrInjuryDetails" className="block text-xs font-medium text-gray-600 mb-1">{t('q3_detailsLabel')}</label>
                 <input id="surgeryOrInjuryDetails" type="text" name="surgeryOrInjuryDetails" value={formData.surgeryOrInjuryDetails} onChange={handleInputChange} className="mt-1 block w-full px-3 py-1.5 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm bg-white" placeholder={t('q3_detailsPlaceholder')} />
            </div>
         )}
      </div>

      {/* Question 4 */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">{t('q4_label')}</label>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {renderCheckbox('illnesses', 'diabetes', 'q4_illness_diabetes')}
            {renderCheckbox('illnesses', 'highBloodPressure', 'q4_illness_highBloodPressure')}
            {renderCheckbox('illnesses', 'highCholesterol', 'q4_illness_highCholesterol')}
            {renderCheckbox('illnesses', 'thyroid', 'q4_illness_thyroid')}
            {renderCheckbox('illnesses', 'arthritis', 'q4_illness_arthritis')}
        </div>
        <input type="text" placeholder={t('q4_illness_other')} value={formData.illnesses.other} onChange={(e) => handleOtherTextChange('illnesses', e.target.value)} className="mt-2 block w-full px-3 py-1.5 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm bg-white" />
      </div>

      {/* Question 5 */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">{t('q5_label')}</label>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {renderCheckbox('familyHistory', 'glaucoma', 'q5_condition_glaucoma')}
            {renderCheckbox('familyHistory', 'macularDegeneration', 'q5_condition_macularDegeneration')}
            {renderCheckbox('familyHistory', 'strabismus', 'q5_condition_strabismus')}
            {renderCheckbox('familyHistory', 'highMyopia', 'q5_condition_highMyopia')}
        </div>
        <input type="text" placeholder={t('q5_condition_other')} value={formData.familyHistory.other} onChange={(e) => handleOtherTextChange('familyHistory', e.target.value)} className="mt-2 block w-full px-3 py-1.5 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm bg-white" />
      </div>
      
      {/* Question 6 */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">{t('q6_label')}</label>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {renderCheckbox('symptoms', 'pain', 'q6_symptom_pain')}
            {renderCheckbox('symptoms', 'itching', 'q6_symptom_itching')}
            {renderCheckbox('symptoms', 'burning', 'q6_symptom_burning')}
            {renderCheckbox('symptoms', 'tearing', 'q6_symptom_tearing')}
            {renderCheckbox('symptoms', 'gritty', 'q6_symptom_gritty')}
            {renderCheckbox('symptoms', 'lightSensitivity', 'q6_symptom_lightSensitivity')}
            {renderCheckbox('symptoms', 'doubleVision', 'q6_symptom_doubleVision')}
            {renderCheckbox('symptoms', 'none', 'q6_symptom_none')}
        </div>
      </div>
      
      <div className="pt-4 border-t border-gray-200">
        <Button type="submit" variant="primary" size="lg" className="w-full">
          {t('questionnaire_submitButton')}
        </Button>
      </div>
    </form>
  );
};