
import React, { useState } from 'react';
import { Page, User } from '../types';
import { Button } from '../components/common/Button';
import { InputField } from '../components/common/InputField';
import { PageContainer } from '../components/common/PageContainer';
import { EyeIcon } from '../constants'; 
import { login, register } from '../services/authService';
import { useLanguage } from '../contexts/LanguageContext';

interface AuthPageProps {
  setCurrentPage: (page: Page) => void;
  setCurrentUser: (user: User | null) => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({ setCurrentPage, setCurrentUser }) => {
  const { t } = useLanguage();
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    if (!isLogin && password !== confirmPassword) {
      setError(t('auth_error_passwordsDoNotMatch'));
      setIsLoading(false);
      return;
    }

    try {
      let user: User | null = null;
      if (isLogin) {
        user = await login(email, password);
      } else {
        user = await register(email, password);
      }
      
      if (user) {
        setCurrentUser(user);
        setCurrentPage(Page.Exam);
      } else {
         setError(isLogin ? t('auth_error_loginFailed') : t('auth_error_registrationFailed'));
      }
    } catch (err) {
       // Check if the error message from authService is a known key
      const errorMessage = (err as Error).message;
      if (errorMessage === "User with this email already exists.") { // Example of specific error from service
        setError(t('auth_error_registrationFailed') + " " + errorMessage); // Or a specific key for this
      } else if (errorMessage === "Invalid email or password.") {
        setError(t('auth_error_loginFailed'));
      }
      else {
        setError(t('auth_error_unexpected'));
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <PageContainer title={isLogin ? t('auth_loginToAccount') : t('auth_createAccount')} className="max-w-md mx-auto">
      <div className="bg-white p-8 rounded-xl shadow-2xl">
        <div className="flex justify-center mb-6">
          <EyeIcon />
        </div>
        <form onSubmit={handleSubmit}>
          <InputField
            label={t('auth_emailLabel')}
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            placeholder={t('auth_emailPlaceholder')}
          />
          <InputField
            label={t('auth_passwordLabel')}
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            placeholder={t('auth_passwordPlaceholder')}
          />
          {!isLogin && (
            <InputField
              label={t('auth_confirmPasswordLabel')}
              id="confirmPassword"
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
              placeholder={t('auth_passwordPlaceholder')}
            />
          )}
          {error && <p className="text-danger text-sm mb-4">{error}</p>}
          <Button type="submit" variant="primary" className="w-full" isLoading={isLoading} size="lg">
            {isLoading 
              ? (isLogin ? t('auth_loggingInButton') : t('auth_registeringButton')) 
              : (isLogin ? t('auth_loginButton') : t('auth_registerButton'))}
          </Button>
        </form>
        <p className="mt-6 text-center text-sm text-gray-600">
          {isLogin ? t('auth_dontHaveAccount') : t('auth_alreadyHaveAccount')}
          <button
            onClick={() => { setIsLogin(!isLogin); setError('');}}
            className="font-medium text-primary hover:text-primary-dark"
          >
            {isLogin ? t('auth_registerHereLink') : t('auth_loginHereLink')}
          </button>
        </p>
      </div>
    </PageContainer>
  );
};
