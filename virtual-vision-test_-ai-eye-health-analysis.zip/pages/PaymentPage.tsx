
import React from 'react';
import { Page } from '../types';
import { Button } from '../components/common/Button';
import { PageContainer } from '../components/common/PageContainer';
import { useLanguage } from '../contexts/LanguageContext';

interface PaymentPageProps {
  setCurrentPage: (page: Page) => void;
}

export const PaymentPage: React.FC<PaymentPageProps> = ({ setCurrentPage }) => {
  const { t } = useLanguage();

  return (
    <PageContainer title={t('payment_title')} className="max-w-lg mx-auto">
      <div className="bg-white p-8 rounded-xl shadow-2xl text-center">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-16 h-16 text-primary mx-auto mb-6">
          <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 8.25h19.5M2.25 9h19.5m-16.5 5.25h6m-6 2.25h3m-3.75 3h15a2.25 2.25 0 0 0 2.25-2.25V6.75A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25v10.5A2.25 2.25 0 0 0 4.5 19.5Z" />
        </svg>
        <p className="text-gray-700 mb-6 leading-relaxed">
          {t('paymentPlaceholderText')}
        </p>
        <div className="mt-8">
           <Button 
            onClick={() => alert(t('payment_processedAlert'))} 
            variant="primary" 
            size="lg"
            className="w-full sm:w-auto"
          >
            {t('payment_simulatePaymentButton')}
          </Button>
        </div>
         <button 
            onClick={() => setCurrentPage(Page.Home)} 
            className="mt-6 text-sm text-primary hover:text-primary-dark"
          >
            {t('payment_returnToHomeLink')}
          </button>
      </div>
    </PageContainer>
  );
};
