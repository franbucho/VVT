
import React, { useState, useEffect } from 'react';
import { Page, EyeAnalysisResult } from '../types';
import { Button } from '../components/common/Button';
import { PageContainer } from '../components/common/PageContainer';
import { LoadingSpinner } from '../components/common/LoadingSpinner';
import { CheckCircleIcon, ExclamationTriangleIcon, XCircleIcon, InfoIcon, LightbulbIcon } from '../constants';
import { getGeneralEyeHealthTips } from '../services/geminiService';
import { useLanguage } from '../contexts/LanguageContext';
import { TranslationKeys } from '../localization/en';


interface ResultsPageProps {
  setCurrentPage: (page: Page) => void;
  analysisResults: EyeAnalysisResult[] | null;
}

const getRiskLevelStyles = (riskLevel: EyeAnalysisResult['riskLevel']) => {
  switch (riskLevel) {
    case 'Low':
      return {
        bgColor: 'bg-green-100',
        textColor: 'text-green-700',
        borderColor: 'border-green-300',
        icon: CheckCircleIcon,
        translationKey: 'results_risk_low' as keyof TranslationKeys
      };
    case 'Medium':
      return {
        bgColor: 'bg-yellow-100',
        textColor: 'text-yellow-700',
        borderColor: 'border-yellow-300',
        icon: ExclamationTriangleIcon,
        translationKey: 'results_risk_medium' as keyof TranslationKeys
      };
    case 'High':
      return {
        bgColor: 'bg-red-100',
        textColor: 'text-red-700',
        borderColor: 'border-red-300',
        icon: XCircleIcon,
        translationKey: 'results_risk_high' as keyof TranslationKeys
      };
    default: // Undetermined or other
      return {
        bgColor: 'bg-gray-100',
        textColor: 'text-gray-700',
        borderColor: 'border-gray-300',
        icon: InfoIcon,
        translationKey: 'results_risk_undetermined' as keyof TranslationKeys
      };
  }
};

export const ResultsPage: React.FC<ResultsPageProps> = ({ setCurrentPage, analysisResults }) => {
  const { t, language } = useLanguage();
  const [eyeTips, setEyeTips] = useState<string>('');
  const [isLoadingTips, setIsLoadingTips] = useState<boolean>(false);
  const [tipsError, setTipsError] = useState<string>('');

  const fetchEyeTips = async () => {
    setIsLoadingTips(true);
    setTipsError('');
    try {
      const tips = await getGeneralEyeHealthTips(language); // Pass current language
      setEyeTips(tips);
    } catch (error) {
      console.error("Failed to fetch eye health tips:", error);
      // Error messages from geminiService are already translation keys
      setTipsError(error instanceof Error ? error.message : t('error_generic_unexpected_api'));
    } finally {
      setIsLoadingTips(false);
    }
  };
  
  useEffect(() => {
    fetchEyeTips();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [language]); // Refetch tips if language changes


  if (!analysisResults) {
    return (
      <PageContainer title={t('results_title')}>
        <LoadingSpinner text={t('results_fetchingTips')} />
      </PageContainer>
    );
  }

  return (
    <PageContainer title={t('results_title')} className="max-w-3xl mx-auto">
      <div className="bg-white p-6 sm:p-8 rounded-xl shadow-2xl">
        <h2 className="text-2xl font-semibold text-neutral-dark mb-6">{t('results_summaryTitle')}</h2>
        
        {analysisResults.length === 0 ? (
          <p className="text-gray-600">{t('results_noResults')}</p>
        ) : (
          <div className="space-y-4 mb-8">
            {analysisResults.map((result, index) => {
              const styles = getRiskLevelStyles(result.riskLevel);
              return (
                <div key={index} className={`p-4 border ${styles.borderColor} ${styles.bgColor} rounded-lg shadow`}>
                  <div className="flex items-center mb-2">
                    <span className="mr-2">{styles.icon}</span>
                    <h3 className={`text-lg font-semibold ${styles.textColor}`}>{t(result.conditionKey as keyof TranslationKeys)}</h3>
                    <span className={`ml-auto px-2 py-0.5 text-xs font-medium ${styles.textColor} ${styles.bgColor} border ${styles.borderColor} rounded-full`}>
                      {t(styles.translationKey)} {t('results_riskLevelSuffix')}
                    </span>
                  </div>
                  <p className={`text-sm ${styles.textColor}`}>{t(result.detailsKey as keyof TranslationKeys)}</p>
                </div>
              );
            })}
          </div>
        )}

        <div className="p-4 bg-yellow-50 border border-yellow-300 rounded-lg mb-8">
          <h4 className="font-semibold text-yellow-800 mb-2 flex items-center">{InfoIcon} {t('results_importantDisclaimerTitle')}</h4>
          <p className="text-sm text-yellow-700 leading-relaxed">{t('resultsDisclaimer')}</p>
        </div>

        <div className="mb-8 p-4 bg-primary-light/10 border border-primary-light rounded-lg">
           <h4 className="font-semibold text-primary-dark mb-3 flex items-center">{LightbulbIcon} {t('results_generalEyeHealthTipsTitle')}</h4>
           {isLoadingTips && <LoadingSpinner size="sm" text={t('results_fetchingTips')} />}
           {tipsError && <p className="text-sm text-danger">{tipsError.startsWith('error_') ? t(tipsError as keyof TranslationKeys) : tipsError}</p>}
           {!isLoadingTips && !tipsError && eyeTips && (
             <div className="text-sm text-neutral-dark space-y-2">
              {eyeTips.split('\n').map((tip, idx) => tip.trim() && <p key={idx}>{tip.startsWith('- ') || tip.startsWith('* ') ? tip : `- ${tip}`}</p>)}
             </div>
           )}
           {!isLoadingTips && (
             <Button onClick={fetchEyeTips} variant="outline" size="sm" className="mt-4">
                {t('results_refreshTipsButton')}
             </Button>
           )}
        </div>

        <div className="text-center">
          <Button onClick={() => setCurrentPage(Page.Payment)} variant="primary" size="lg">
            {t('results_proceedToPaymentButton')}
          </Button>
           <Button onClick={() => setCurrentPage(Page.Exam)} variant="outline" size="md" className="ml-4">
            {t('results_performAnotherAnalysisButton')}
          </Button>
        </div>
      </div>
    </PageContainer>
  );
};
